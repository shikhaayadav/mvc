package com.lab.LabMvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabMvcApplication.class, args);
	}

}
