package com.lab.LabMvc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lab.LabMvc.model.Trainee;
public interface TraineeRepository extends JpaRepository<Trainee, Integer>{

}
