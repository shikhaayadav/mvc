package com.lab.LabMvc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lab.LabMvc.model.Trainee;
import com.lab.LabMvc.repository.TraineeRepository;


@Service
public class TraineeService {
	@Autowired
	TraineeRepository traineeRepository;
	
	@Transactional
	public void insertTrainee(Trainee trainee) {
		traineeRepository.saveAndFlush(trainee);
    }
	
	public Trainee findTrainee(int traineeId){
		Optional<Trainee> opt=traineeRepository.findById(traineeId);
		if(opt.isPresent()) 
			return opt.get();	
		return null;
	}
	
	public List<Trainee> getTrainees(){
		return traineeRepository.findAll();
		
	}
	public void removeTrainee(int traineeId) {
		Optional<Trainee> opt=traineeRepository.findById(traineeId);
		if(opt.isPresent())
		 {
			Trainee train=opt.get();
			traineeRepository.delete(train);
		 } 
	}
	
	 public Trainee updateTrainee(Trainee e) {
	    	return traineeRepository.save(e);
	    }
}
